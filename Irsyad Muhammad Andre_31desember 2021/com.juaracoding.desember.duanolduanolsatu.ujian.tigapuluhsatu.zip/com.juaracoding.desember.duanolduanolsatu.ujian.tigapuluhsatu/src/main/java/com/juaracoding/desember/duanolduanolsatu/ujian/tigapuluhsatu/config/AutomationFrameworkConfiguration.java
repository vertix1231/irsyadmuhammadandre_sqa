package com.juaracoding.desember.duanolduanolsatu.ujian.tigapuluhsatu.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.juaracoding.desember.duanolduanolsatu.ujian.tigapuluhsatu")
public class AutomationFrameworkConfiguration {
	
	public AutomationFrameworkConfiguration() {
		
	}
}
