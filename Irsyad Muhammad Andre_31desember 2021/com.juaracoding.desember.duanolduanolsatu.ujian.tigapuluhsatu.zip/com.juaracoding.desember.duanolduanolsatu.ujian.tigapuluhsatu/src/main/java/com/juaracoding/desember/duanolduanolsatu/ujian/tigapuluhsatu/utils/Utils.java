package com.juaracoding.desember.duanolduanolsatu.ujian.tigapuluhsatu.utils;

public class Utils {
	public static int testcountt=0;
	
}
