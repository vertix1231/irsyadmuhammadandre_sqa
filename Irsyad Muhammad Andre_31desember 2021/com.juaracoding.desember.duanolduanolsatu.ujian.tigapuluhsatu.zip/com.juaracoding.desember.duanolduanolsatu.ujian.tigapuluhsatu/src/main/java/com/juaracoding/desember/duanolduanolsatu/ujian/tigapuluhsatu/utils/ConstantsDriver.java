package com.juaracoding.desember.duanolduanolsatu.ujian.tigapuluhsatu.utils;

public class ConstantsDriver {
	
	public static final String CHROME= "Chrome";
	public static final String FIREFOX= "Firefox";
	public static final String EMAIL= "email";
	public static final String PASSWORD= "password";
	public static final String BROWSER= "browser";
	
	public static final String URL= "https://shop.demoqa.com/";
	public static final String USE_USERNAME= "irsyadandretttttttttttttttttttt";
	public static final String USE_EMAIL= "irsyad_vertixtttttttttttttttttttt@gmail.com";
	public static final String USE_PASSWORD= "irsyad_vertixt14129812_";
	
	
}
