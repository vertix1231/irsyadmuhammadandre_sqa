package com.juaracoding.ujian.duaempatdesember.driver;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {
	
	public WebDriver setStrategy();
}
